class Configs {
  static const baseUrl = 'http://localhost:5240';
}
