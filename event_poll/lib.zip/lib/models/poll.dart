class Poll{
  Poll({
    required this.name,
    required this.description, 
    required this.eventDate, 
  });
  String name;
  String description;
  DateTime eventDate;


  Poll.fromJson(Map<String, dynamic> json)
    : this(
      name: json['name'] as String,
      description: json['description'] as String, 
      eventDate: DateTime.parse(json['eventDate']),
    );
}