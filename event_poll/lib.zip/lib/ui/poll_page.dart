import 'package:event_poll/result.dart';
import 'package:event_poll/states/polls_state.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/poll.dart';

class PollPage extends StatefulWidget {
  @override
  _PollPageState createState() => _PollPageState();
}

class _PollPageState extends State<PollPage> {

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Result<List<Poll>,String>>(
      future: context.read<PollsState>().getPolls(),
      builder: (context,snapshot){
        List<Widget> widgets = [];
        final dateFormater = DateFormat('dd/MM/yyyy', 'fr');
        if(snapshot.hasData){
          snapshot.data!.value!.forEach((Poll poll) {
              widgets.add(
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    
                    children: [
                      Column(
                        children: [
                            Text(poll.name),
                            Text(poll.description),
                        ],
                      ),
                      Column(
                        children: [
                          Text(dateFormater.format(poll.eventDate)),
                        ],
                      )
                    ],
                  ),
                )
                 
              );
            });
          return Row(children: widgets,);
        }else{
          return const Text("pas");
        }
      },
    );
  }
}